package uz.ibrokhimov.quizislamic.core.model

data class SavolModel(
    val id:Int,
    val savol:String,
    val javoblar: ArrayList<String>,
    val javob:String
)